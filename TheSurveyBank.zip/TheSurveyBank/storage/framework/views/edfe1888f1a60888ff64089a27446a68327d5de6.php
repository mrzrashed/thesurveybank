<?php $__env->startSection('contents'); ?>
<div class="card">
  <form class="form" action="<?php echo e(url('survey/submitresult')); ?>" method="post">
    <?php echo csrf_field(); ?>
  <div class="card-header">
      <div class="row">
          <div class="col-md-8">
                <h3>Title:<?php echo e($survey->title); ?></h3>
                <input type="hidden" name="survey_id" value="<?php echo e($survey->survey_id); ?>">

                <?php
                $questions = \App\Result::where('survey_id', $survey->survey_id)->where('user_id',Auth::user()->id)->get()->count();
                ?>

                

          </div>
          <div class="col-md-4 text-right">
              <a href="<?php echo e(url('user/survey')); ?>" class="btn btn-sm btn-info"><i class="fa fa-th"></i> All Survey</a>
          </div>
      </div>
  </div>
  <div class="card-body">
    <?php if($questions >=5): ?>
    <h4>You have Submitted this survey</h4>


    <?php else: ?>
    <?php
    $questions = \App\Question::where('survey_id', $survey->survey_id)->get();
    $i=0;
    $j=0;
    ?>
    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="row mb-5">
          <div class="col-md-12">
              <h4><?php echo e(++$key); ?>.<span>&nbsp</span><?php echo e($question->question_title); ?></h4>
              <input type="hidden" name="question_id<?php echo e($key); ?>" value="<?php echo e($question->question_id); ?>">


          </div>
          <div class="col-md-12 ml-5">
            <?php
            ++$i;
            ?>
            <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <input type="radio" id="radio<?php echo e($j); ?>" name="group<?php echo e($i); ?>" value="<?php echo e($option->option_id); ?>" required/>
            <label for="radio<?php echo e($j); ?>"><?php echo e($option->title); ?></label>
            <?php
            ++$j;
            ?>

            <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </div>
  <div class="card-footer">
      <div class="row">
          <div class="col-md-8">
          </div>
          <div class="col-md-4 text-right">
            <input type="submit" class="btn btn-sm btn-info">
          </div>
      </div>
      <?php endif; ?>
  </div>
</form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>