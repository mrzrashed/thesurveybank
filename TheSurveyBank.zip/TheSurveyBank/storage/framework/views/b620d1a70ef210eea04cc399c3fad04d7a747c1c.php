<?php $__env->startSection('contents'); ?>
<div class="card">
    <form class="form" action="<?php echo e(url('survey/add/insertSurvey')); ?>" method="post">
        <div class="card-header">
            <div class="row">
                <div class="col-md-8">
                    <h3>Title:</h3>
                </div>
                <div class="col-md-4 text-right">
                    <a href="#" class="btn btn-sm btn-info"><i class="fa fa-th"></i> All Survey</a>
                </div>
            </div>
        </div>
        <div class="card-body">
          <?php $__currentLoopData = $data['questions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row mb-5">
                <div class="col-md-12">
                    <h4><?php echo e($question->question_id); ?>. <?php echo e($question->question_title); ?></h4>
                </div>
                <input type="hidden" name="<?php echo e($question->question_id); ?>">
                <div class="col-md-12 ml-5">
                  <input type="radio" name="group<?php echo e($key); ?>" />
                  <label for="group<?php echo e($key); ?>">Strongly Agree</label>
                  <input type="radio" name="group<?php echo e($key); ?>" />
                  <label for="group<?php echo e($key); ?>">Agree</label>
                  <input type="radio" name="group<?php echo e($key); ?>" />
                  <label for="group<?php echo e($key); ?>">Neutral</label>
                  <input type="radio" name="group<?php echo e($key); ?>" />
                  <label for="group<?php echo e($key); ?>">Disagree</label>
                  <input type="radio" name="group<?php echo e($key); ?>" />
                  <label for="group<?php echo e($key); ?>">Strongly Disagree</label>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

        <div class="card-footer">
            <div class="row">
                <div class="col-md-8">
                </div>
                <div class="col-md-4 text-right">
                    <input type="submit" class="btn btn-sm btn-info">
                </div>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>