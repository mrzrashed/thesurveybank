<?php $__env->startSection('content'); ?>
                    <div class="middle-box">
                        <div class="card">
                            <!-- Logo -->
                            <div class="card-header pt-4 pb-4  text-center bg-primary">
                                <a href="<?php echo e(url('userLogin')); ?>">
                                    <h4 class="mb-0 font-24 text-white"><?php echo e(__('The Survey Bank')); ?></h4>
                                </a>
                            </div>
                            <div class="card-body p-4">
                                <div class="text-center w-75 m-auto">
                                    <h4 class="text-dark-50 text-center mt-0 font-weight-bold">Sign In</h4>
                                    <p class="text-muted mb-4">Enter your email address and password to Dashboard.</p>
                                </div>
                                <form method="POST" action="<?php echo e(route('login')); ?>" aria-label="<?php echo e(__('Login')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <input class="form-control" type="email" id="emailaddress" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus placeholder="Enter your email">
                                        <?php if($errors->has('email')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('email')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>

                                    <div class="form-group">
                                        <input class="form-control" type="password" required="" id="password" placeholder="Enter your password"class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                                        <?php if($errors->has('password')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('password')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>

                                    <div class="form-group mb-3">
                                        <div class="custom-control custom-checkbox">

                                            <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                            <label class="form-check-label ml-4 mb-1" for="remember">
                                                <?php echo e(__('Remember Me')); ?>

                                            </label>
                                            <br>
                                            <a href="register.html" class="text-muted float-left"><small>New member register here!</small></a> <a href="forget-password.html" class="text-muted float-right"><small>Forgot your password?</small></a>

                                        </div>
                                    </div>
                                    <div class="form-group mb-0 text-center">
                                      <br>
                                      <button type="submit" class="btn btn-primary">
                                          <?php echo e(__('Login')); ?>

                                      </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div>
                            <a href="contact.html" class="text-muted float-right"><small>Need Help?</small></a>
                        </div>
                    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>