<?php $__env->startSection('contents'); ?>
<div class="card">
  <div class="card-header">
      <div class="row">
          <div class="col-md-8">
                <h3>Title:<?php echo e($survey->title); ?></h3>
          </div>
          <div class="col-md-4 text-right">
              <a href="<?php echo e(url('profile/survey')); ?>" class="btn btn-sm btn-info"><i class="fa fa-th"></i> All Survey</a>
          </div>
      </div>
  </div>
  <div class="card-body">
    <?php
    $questions = \App\Question::where('survey_id', $survey->survey_id)->get();
    $i=0;
    ?>
    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="row mb-5">
          <div class="col-md-12">

              <h4><?php echo e(++$key); ?>.<span>&nbsp</span><?php echo e($question->question_title); ?></h4>
              <input type="hidden" name="question_id" value="<?php echo e($question->question_id); ?>">
          </div>
          <div class="col-md-12 ml-5">
            <?php
            ++$i;
            ?>
            <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


            <?php
              $comments = App\Result::where('option_id', $option->option_id)->get();
            ?>
            <label style="font-size:15px; font-weight:800;">Total Vote:&nbsp; <font style="color: #1976d2;"><?php echo e(count($comments)); ?></font></label>
            <input type="radio" name="group<?php echo e($i); ?>" value="<?php echo e($option->option_id); ?>"/>
            <label for=""><?php echo e($option->title); ?></label><br>
            <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <div class="card-footer">
      <div class="row">
          <div class="col-md-8">
          </div>
          <div class="col-md-4 text-right">
          </div>
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>