<?php $__env->startSection('contents'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
          <?php if(Session::has('success')): ?>
            <script>
                swal({ title: "Success!", text: "Someone response on Survey.", timer:5000, icon: "success",});
            </script>
          <?php endif; ?>
          <?php if(Session::has('delete_success')): ?>
            <script>
                swal({ title: "Success!", text: "Deleted Succefully", timer:5000, icon: "success",});
            </script>
          <?php endif; ?>
          <?php if(Session::has('error')): ?>
           <script>
               swal({ title: "Opps!", text: "Anyone Does not attent on Survey.", timer:5000, icon: "warning",});
           </script>
         <?php endif; ?>
            <div class="card-body">
                <h4 class="card-title">Your Survey</h4>
                <div class="row">
                    <div class="col-md-8">
                    </div>
                    <div class="col-md-4 text-right">
                        <a href="<?php echo e(url('survey/add')); ?>" class="btn btn-sm btn-info"><i class="fa fa-th"></i> Create Survey</a>
                    </div>
                </div>
                <div class="table-responsive m-t-40">
                    <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Title</th>
                                <th>Creator</th>
                                <th>Manage</th>
                            </tr>
                        </thead>


                        <tbody>
                          <?php
                            $i= 1;
                          ?>
                          <?php $__currentLoopData = $allSurvey; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$id); ?></td>
                                <td><?php echo e($data->title); ?></td>
                                <td><?php echo e($data->researcherName->name); ?></td>

                                <td>
                                    <a href="<?php echo e(url('survey/view/'.$data->survey_id)); ?>" class="btn btn-sm btn-info"> Details</a>
                                    <a href="<?php echo e(url('view/result/'.$data->survey_id)); ?>" class="btn btn-sm btn-info"></i>Report</a>
                                    <a href="<?php echo e(url('survey/delete/'.$data->survey_id)); ?>" data-toggle="tooltip" data-original-title="Delete"> <i class="fa fa-close text-danger"></i> </a>
                                </td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>