<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>The Survey Bank - Forget Password</title>
    <link rel="icon" href="<?php echo e(asset('contents')); ?>/img/logo-survey-bank/favicon.png">
    <link rel="stylesheet" href="<?php echo e(asset('contents')); ?>/style.css">
</head>

<body class="login-area bg-img bg-overlay-white">
    <div class="main-content- h-100vh">
        <div class="container h-100">
            <div class="row h-100 justify-content-center align-items-center">
                <div class="col-lg-5 mx-auto">
<?php echo $__env->yieldContent('content'); ?>



                </div>
            </div>
        </div>
    </div>
    <script src="<?php echo e(asset('contents')); ?>/js/jquery.min.js"></script>
    <script src="<?php echo e(asset('contents')); ?>/js/popper.min.js"></script>
    <script src="<?php echo e(asset('contents')); ?>/js/bootstrap.min.js"></script>
    <script src="<?php echo e(asset('contents')); ?>/js/ecaps.bundle.js"></script>
    <script src="<?php echo e(asset('contents')); ?>/js/default-assets/active.js"></script>
</body>

</html>
