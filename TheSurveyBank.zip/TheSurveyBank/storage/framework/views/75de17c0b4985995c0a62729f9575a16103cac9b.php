<?php $__env->startSection('contents'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Your Survey</h4>
                <h5>We will keep your identity private, Don't Worry About It!</h5>
                <div class="row">
                    <div class="col-md-8">
                    </div>
                </div>
                <div class="table-responsive m-t-40">
                    <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Title</th>
                                <th>Creator</th>
                                <th>Manage</th>
                            </tr>
                        </thead>
                        <tbody>
                          <?php
                            $i= 1;
                          ?>
                          <?php $__currentLoopData = $allSurvey; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$id); ?></td>
                                <td><?php echo e($data->title); ?></td>
                                <td><?php echo e($data->researcherName->name); ?></td>
                                <td>
                                    <a href="<?php echo e(url('user/view/'.$data->survey_id)); ?>" class="btn btn-sm btn-info">Submit Your Opinions</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>