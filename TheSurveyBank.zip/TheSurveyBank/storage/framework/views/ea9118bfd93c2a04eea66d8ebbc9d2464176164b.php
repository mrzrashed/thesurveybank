<?php $__env->startSection('contents'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header text-center text-light bg-primary"><?php echo e(__('The Survey Bank - Update')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(url('profile/update')); ?>" aria-label="<?php echo e(__('Update')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

                            <div class="col-md-6">
                                <input value="<?php echo e($user->name); ?>" id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>"  required autofocus>

                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>

                            <div class="col-md-6">
                                <input value="<?php echo e($user->email); ?>" id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" disabled>

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="depart" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Departmet')); ?></label>

                            <div class="col-md-6">
                                <select value="<?php echo e($user->dept); ?>" id="depart" type="text" class="form-control<?php echo e($errors->has('depart') ? ' is-invalid' : ''); ?>" name="depart" value="<?php echo e(old('dept')); ?>" required>

                                  <?php if($user->department == 1): ?>
                                  <option value="1">CSE</option>
                                  <?php elseif($user->department== 2): ?>
                                  <option value="2">SWE</option>
                                  <?php elseif($user->department== 3): ?>
                                  <option value="3">BBA</option>
                                  <?php elseif($user->department== 4): ?>
                                  <option value="4">EEE</option>
                                  <?php endif; ?>

                                  <option value="1">CSE</option>
                                  <option value="2">SWE</option>
                                  <option value="3">BBA</option>
                                  <option value="4">EEE</option>
                                </select>

                                <?php if($errors->has('dept')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('dept')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="utype" class="col-md-4 col-form-label text-md-right"><?php echo e(__('User Type')); ?></label>

                            <div class="col-md-6">
                                <select id="utype" class="form-control<?php echo e($errors->has('utype') ? ' is-invalid' : ''); ?>" name="utype" value="<?php echo e(old('utype')); ?>" required>
                                  <?php if($user->userRole == 4): ?>
                                  <option value="4">Reseacher</option>
                                  <?php elseif($user->userRole == 5): ?>
                                  <option value="5" >Survey User</option>
                                  <?php endif; ?>
                                  <option value="4">Reseacher</option>
                                  <option value="5" >Survey User</option>
                                </select>

                                <?php if($errors->has('utype')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('utype')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="semester" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Semester/Position')); ?></label>

                            <div class="col-md-6">
                                <select id="semester" class="form-control<?php echo e($errors->has('semester') ? ' is-invalid' : ''); ?>" name="semester" value="<?php echo e(old('semester')); ?>" required>
                                  <?php if($user->semester == 1): ?>
                                  <option value="1" >First Semester</option>
                                  <?php elseif($user->semester	== 2): ?>
                                  <option value="2" >Second Semester</option>
                                  <?php elseif($user->semester	== 3): ?>
                                  <option value="3" >Third Semester</option>
                                  <?php elseif($user->semester	== 4): ?>
                                  <option value="4" >Fourth Semester</option>
                                  <?php elseif($user->semester	== 5): ?>
                                  <option value="5" >Fifth Semester</option>
                                  <?php elseif($user->semester	== 6): ?>
                                  <option value="6" >Sixth Semester</option>
                                  <?php elseif($user->semester	== 7): ?>
                                  <option value="7" >Seven Semester</option>
                                  <?php elseif($user->semester	== 8): ?>
                                  <option value="8" >Eight Semester</option>
                                  <?php elseif($user->semester	== 9): ?>
                                  <option value="9" >Nine Semester</option>
                                  <?php elseif($user->semester	== 10): ?>
                                  <option value="10" >Ten Semester</option>
                                  <?php elseif($user->semester	== 11): ?>
                                  <option value="11" >Eleven Semester</option>
                                  <?php elseif($user->semester	== 12): ?>
                                  <option value="12" >Twelve Semester</option>
                                  <?php elseif($user->semester	== 13): ?>
                                  <option value="13" >Teacher</option>
                                  <?php endif; ?>
                                  <option value="1" >First Semester</option>
                                  <option value="2" >Second Semester</option>
                                  <option value="3" >Third Semester</option>
                                  <option value="4" >Fourth Semester</option>
                                  <option value="5" >Fifth Semester</option>
                                  <option value="6" >Sixth Semester</option>
                                  <option value="7" >Seven Semester</option>
                                  <option value="8" >Eight Semester</option>
                                  <option value="9" >Nine Semester</option>
                                  <option value="10" >Ten Semester</option>
                                  <option value="11" >Eleven Semester</option>
                                  <option value="12" >Twelve Semester</option>
                                  <option value="13" >Teacher</option>
                                </select>
                                <?php if($errors->has('semester')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('semester')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4 text-right">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Update')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>